<?php
session_start();

// Check if admin is logged in
if (!isset($_SESSION['admin_logged_in']) || $_SESSION['admin_logged_in'] !== true) {
    header('Location: login.php');
    exit();
}

$admin_username = $_SESSION['admin_username'] ?? 'Admin';
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard - Dwarkesh Menswear</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;700&display=swap" rel="stylesheet">
    <style>
        :root {
            --primary-black: #0a0a0a;
            --secondary-black: #1a1a1a;
            --dark-gray: #2a2a2a;
            --gold: #ffd700;
            --gold-hover: #ffed4e;
            --text-light: #ffffff;
            --text-gray: #cccccc;
            --gradient-dark: linear-gradient(135deg, #0a0a0a 0%, #1a1a1a 50%, #2a2a2a 100%);
            --gradient-gold: linear-gradient(135deg, #ffd700 0%, #ffed4e 100%);
        }

        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background: var(--gradient-dark);
            color: var(--text-light);
            line-height: 1.6;
        }

        .navbar {
            background: rgba(10, 10, 10, 0.95) !important;
            backdrop-filter: blur(10px);
            border-bottom: 1px solid var(--gold);
        }

        .navbar-brand {
            color: var(--gold) !important;
            font-family: 'Playfair Display', serif;
            font-weight: 700;
            letter-spacing: 1px;
        }

        .btn-gold {
            background: var(--gradient-gold);
            border: none;
            color: var(--primary-black);
            font-weight: 600;
            padding: 12px 30px;
            border-radius: 50px;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
        }

        .btn-gold:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(255, 215, 0, 0.3);
            color: var(--primary-black);
        }

        .btn-danger {
            background: linear-gradient(135deg, #dc3545 0%, #c82333 100%);
            border: none;
            color: white;
            font-weight: 600;
            padding: 12px 30px;
            border-radius: 50px;
            transition: all 0.3s ease;
        }

        .btn-danger:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(220, 53, 69, 0.3);
            color: white;
        }

        .btn-info {
            background: linear-gradient(135deg, #17a2b8 0%, #138496 100%);
            border: none;
            color: white;
            font-weight: 600;
            padding: 12px 30px;
            border-radius: 50px;
            transition: all 0.3s ease;
        }

        .btn-info:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(23, 162, 184, 0.3);
            color: white;
        }

        .btn-success {
            background: linear-gradient(135deg, #28a745 0%, #20c997 100%);
            border: none;
            color: white;
            font-weight: 600;
            padding: 12px 30px;
            border-radius: 50px;
            transition: all 0.3s ease;
        }

        .btn-success:hover {
            transform: translateY(-3px);
            box-shadow: 0 10px 25px rgba(40, 167, 69, 0.3);
            color: white;
        }

        .dashboard-header {
            background: var(--secondary-black);
            padding: 3rem 0;
            border-bottom: 2px solid var(--gold);
        }

        .dashboard-title {
            color: var(--gold);
            font-family: 'Playfair Display', serif;
            font-weight: 700;
        }

        .admin-info {
            background: var(--dark-gray);
            border-radius: 15px;
            padding: 1.5rem;
            margin-bottom: 2rem;
            border: 1px solid var(--gold);
        }

        .action-card {
            background: var(--dark-gray);
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            border: 2px solid transparent;
            transition: all 0.3s ease;
            height: 100%;
        }

        .action-card:hover {
            border-color: var(--gold);
            transform: translateY(-5px);
            box-shadow: 0 15px 35px rgba(255, 215, 0, 0.2);
        }

        .action-icon {
            font-size: 3rem;
            color: var(--gold);
            margin-bottom: 1rem;
        }

        .action-card h5 {
            color: var(--gold);
            margin-bottom: 1rem;
        }

        .action-card p {
            color: var(--text-gray);
            margin-bottom: 1.5rem;
        }

        .stats-section {
            background: var(--secondary-black);
            padding: 3rem 0;
        }

        .stat-card {
            background: var(--dark-gray);
            border-radius: 15px;
            padding: 2rem;
            text-align: center;
            border: 1px solid var(--gold);
            transition: all 0.3s ease;
        }

        .stat-card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 25px rgba(255, 215, 0, 0.2);
        }

        .stat-number {
            font-size: 2.5rem;
            color: var(--gold);
            font-weight: 700;
            margin-bottom: 0.5rem;
        }

        .stat-label {
            color: var(--text-gray);
            font-size: 0.9rem;
        }

        @media (max-width: 768px) {
            .dashboard-header {
                padding: 2rem 0;
            }
            
            .action-card {
                margin-bottom: 1rem;
            }
        }
    </style>
</head>
<body>
    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark fixed-top">
        <div class="container">
            <a class="navbar-brand fw-bold" href="../index.html">
                <i class="fas fa-tshirt me-2"></i>Dwarkesh Menswear
            </a>
            <div class="navbar-nav ms-auto">
                <span class="navbar-text me-3">
                    <i class="fas fa-user-shield me-2"></i>Welcome, <?php echo htmlspecialchars($admin_username); ?>
                </span>
                <a href="logout.php" class="btn btn-danger btn-sm">
                    <i class="fas fa-sign-out-alt me-2"></i>Logout
                </a>
            </div>
        </div>
    </nav>

    <!-- Dashboard Header -->
    <section class="dashboard-header">
        <div class="container">
            <div class="row align-items-center">
                <div class="col-lg-8">
                    <h1 class="dashboard-title">
                        <i class="fas fa-tachometer-alt me-3"></i>Admin Dashboard
                    </h1>
                    <p class="text-light mb-0">Manage your clothing store products and inventory</p>
                </div>
                <div class="col-lg-4 text-lg-end">
                    <div class="admin-info">
                        <h6 class="text-gold mb-2">Admin Panel</h6>
                        <p class="text-light mb-0">
                            <i class="fas fa-clock me-2"></i>
                            Last login: <?php echo date('M d, Y H:i'); ?>
                        </p>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Statistics Section -->
    <section class="stats-section">
        <div class="container">
            <h2 class="text-center text-gold mb-5">Store Statistics</h2>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6">
                    <div class="stat-card">
                        <div class="stat-number">24</div>
                        <div class="stat-label">Total Products</div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="stat-card">
                        <div class="stat-number">150+</div>
                        <div class="stat-label">Happy Customers</div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="stat-card">
                        <div class="stat-number">₹45K</div>
                        <div class="stat-label">Monthly Revenue</div>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="stat-card">
                        <div class="stat-number">4.8</div>
                        <div class="stat-label">Average Rating</div>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Action Buttons Section -->
    <section class="py-5">
        <div class="container">
            <h2 class="text-center text-gold mb-5">Product Management</h2>
            <div class="row g-4">
                <div class="col-lg-4 col-md-6">
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-plus-circle"></i>
                        </div>
                        <h5>Add Product</h5>
                        <p>Add new products to your inventory with images, descriptions, and pricing.</p>
                        <a href="#" class="btn btn-success">
                            <i class="fas fa-plus me-2"></i>Add Product
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-edit"></i>
                        </div>
                        <h5>Update Product</h5>
                        <p>Modify existing product information, prices, and inventory levels.</p>
                        <a href="#" class="btn btn-info">
                            <i class="fas fa-edit me-2"></i>Update Product
                        </a>
                    </div>
                </div>
                <div class="col-lg-4 col-md-6">
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-trash-alt"></i>
                        </div>
                        <h5>Delete Product</h5>
                        <p>Remove products from your inventory that are no longer available.</p>
                        <a href="#" class="btn btn-danger">
                            <i class="fas fa-trash me-2"></i>Delete Product
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Quick Actions Section -->
    <section class="py-5" style="background: var(--secondary-black);">
        <div class="container">
            <h2 class="text-center text-gold mb-5">Quick Actions</h2>
            <div class="row g-4">
                <div class="col-lg-3 col-md-6">
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-chart-bar"></i>
                        </div>
                        <h5>View Analytics</h5>
                        <p>Check sales reports and customer analytics.</p>
                        <a href="#" class="btn btn-gold">View Reports</a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-users"></i>
                        </div>
                        <h5>Customer Reviews</h5>
                        <p>Manage and respond to customer reviews.</p>
                        <a href="#" class="btn btn-gold">Manage Reviews</a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-cog"></i>
                        </div>
                        <h5>Settings</h5>
                        <p>Configure store settings and preferences.</p>
                        <a href="#" class="btn btn-gold">Settings</a>
                    </div>
                </div>
                <div class="col-lg-3 col-md-6">
                    <div class="action-card">
                        <div class="action-icon">
                            <i class="fas fa-question-circle"></i>
                        </div>
                        <h5>Help & Support</h5>
                        <p>Get help with admin panel features.</p>
                        <a href="#" class="btn btn-gold">Get Help</a>
                    </div>
                </div>
            </div>
        </div>
    </section>

    <!-- Footer -->
    <footer class="py-4" style="background: var(--primary-black); border-top: 2px solid var(--gold);">
        <div class="container">
            <div class="text-center">
                <p class="text-light mb-0">
                    <i class="fas fa-shield-alt me-2"></i>
                    Admin Panel - Dwarkesh Menswear | Secure Access Only
                </p>
            </div>
        </div>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html> 